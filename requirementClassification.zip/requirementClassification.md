﻿**Story name**: Customer order 

**Description** : As a customer , I need to place an order so that I can have food delivered to my house.

**Functional Requirements:**

The system should return restaurants within a 20 km radius.

1. Order should be placed when the customer confirms the order. 
1. Can I save my order and come back later.
1. Can I see a running total of the cost of what I have chosen so far.
1. Users should be able to view the information about a restaurant by going to their page.
1. Restaurant admins can add/update/delete their information.
1. Authentication 

**Non-function Requirements :** 

1. Availability : Can I place an order at any time.
1. Can I view my order at any time.
1. Performance : The website pages should load in 3 secs with total of more than 5000 users.
1. Scalable : Can it support more than 2 million people from next month.
1. Reliability :  It provides a reliable and robust user experiences.
1. Responsive web UI : Less complex UI.![](Aspose.Words.f1a28860-f8af-4804-9760-eef27c33e096.001.png)

